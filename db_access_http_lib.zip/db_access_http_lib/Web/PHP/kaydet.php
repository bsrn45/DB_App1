<?php
    if($_POST){
        // androiddden gelen verileri al ve değişkene aktar
        $ad = stripslashes($_POST["ad"]);
        $eposta = stripslashes($_POST["eposta"]);
        $metin = stripslashes($_POST["metin"]);

        // veritabanı bağlantısını oluştur
        try{
            $baglanti = new PDO("mysql:host=localhost;dbname=egitim_db;charset=utf8", "berkay", "123456");
            $baglanti -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }catch(PDOException $e){
            print $e -> getMessage();
        }

        $gir = $baglanti -> prepare("INSERT INTO veriler SET ad = :a, eposta = :e, metin = :m, gonderilme = :g");
        $sql_giris = $gir -> execute(array("a" => $ad, "e" => $eposta, "m" => $metin, "g" => time()));

        if($sql_giris){
            $data[] = array(
                "islem" => true
            );
        }else{
            $data[] = array(
                "islem" => false
            );
        }

        // son hazırlanan veriyi json formatında ekrana bas.
        header("Content-type: application/json");
        echo json_encode($data);
    }
?>
